/**
 * 
 */

/**
 * @author apple
 *
 */
public class Identical_arrays7_27 
{
	public static void main(String[] args) 
	{
		//Read user input
		java.util.Scanner input = new java.util.Scanner(System.in);
		
		//Read first array
		System.out.print("Enter list 1: ");
		int list_1_length = input.nextInt();
		int[] list_1 = new int[list_1_length];
		for(int i=0; i<list_1_length; i++)
		{
			list_1[i] = input.nextInt();
		}
		
		//Read second array
		System.out.print("Enter list 2: ");
		int list_2_length = input.nextInt();
		int[] list_2 = new int[list_2_length];
		for(int i=0; i<list_2_length; i++)
		{
			list_2[i] = input.nextInt();
		}
		
		//If the length is not equal, 
		//the two arrays are directly judged to be unequal
		if(list_1_length != list_2_length)
		{
			System.out.print("Two list are not identical");
		}
		
		//Output result
		if(equals(list_1 , list_2))
		{
			System.out.print("Two list are identical");
		}
		else
		{
			System.out.print("Two list are not identical");
		}

	}
	
	/**The "equals" method uses the "sort" function to sort in ascending order, 
	 * and then uses the "for" loop statement to compare whether 
	 * the values corresponding to each subscript are equal. 
	 */
	public static boolean equals(int[] list_1 , int[] list_2)
	{
		//Sort in ascending order
		java.util.Arrays.sort(list_1);
		java.util.Arrays.sort(list_2);
		
		//Judge whether it is equal
		for(int i=0; i<list_1.length; i++)
		{
			if(list_1[i] != list_2[i])
			{
				return false;
			}
		}
		
		return true;
	}

}
