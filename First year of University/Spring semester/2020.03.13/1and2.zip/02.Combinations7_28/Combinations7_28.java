/**This program will use the "for" loop to output the pairing of two numbers in turn.
 * 
 */

/**
 * @author apple
 *
 */
public class Combinations7_28 
{
	public static void main(String[] args) 
	{
		//Read user input
		java.util.Scanner input = new java.util.Scanner(System.in);
		int[] number = new int[10];
		System.out.print("Enter the integers: ");
		for(int i=0; i<10; i++)
		{
			number[i] = input.nextInt();
		}
		
		//Output result
		for(int i=0; i<10; i++)
		{
			for(int j=i+1; j<10; j++)
			{
				System.out.print(number[i]+" "+number[j]+"\t");
			}
			System.out.println();//Line feed
		}

	}

}
